# API実行結果

## categories/GET
<img width="1284" alt=":categories:get" src="https://user-images.githubusercontent.com/87253195/151834049-3c551e31-cc6b-4159-8408-db4f425f6928.png"><br><br><br>

## categories/POST
<img width="1284" alt=":categories:post" src="https://user-images.githubusercontent.com/87253195/151834091-81a20efd-edc3-4d90-ad90-90f562e87f83.png">

## ideas/GET
<img width="1284" alt=":ideas:get" src="https://user-images.githubusercontent.com/87253195/151834106-3db58ccf-c677-4404-a921-b6dac0b93ee6.png">

## categoriesModel 単体テスト
<img width="1339" alt="categoryModelテスト" src="https://user-images.githubusercontent.com/87253195/151834120-818161dc-b559-49b2-a437-fffa4ddb3011.png">


### ideas/POST
実力不足のため、期限内に実装することができませんでした。

### ideasModel 単体テスト
同上になります。