require 'rails_helper'

RSpec.describe "Ideas", type: :request do

end
