require 'rails_helper'

RSpec.describe "Categories", type: :request do
  describe 'POST /categorie' do
    it 'GET /categories'
      expect(response).to have_http_status(201)
    end
end
